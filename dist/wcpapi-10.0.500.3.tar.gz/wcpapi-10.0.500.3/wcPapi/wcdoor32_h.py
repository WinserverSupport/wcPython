# Auto-Created by cpp2py.py
import os
from wcpapi.wctype_constants_h import *
from wcpapi.wctype_h import *
from wcpapi.__init__ import *

wcdoor32_dll = initialize_wcdoor32_dll()

#//***********************************************************************
#// (c) Copyright 1998-2025 Santronics Software, Inc. All Rights Reserved.
#//***********************************************************************
#//
#// File Name : wcdoor32.h
#// Subsystem : Wildcat! Door32
#// Date      : 01/29/2025
#// Version   : 454.16
#// Author    : HLS-DS
#//
#// Revision History:
#// Build    Date      Author  Comments
#// -----    --------  ------  -------------------------------------------
#// 452.5    03/07/08  HLS     - Added WCDOOR_EVENT_XXXXXX
#//                            - Added DoorEvent()
#//
#// 452.6    10/01/08  HLS     - Renamed door32.h to wcdoor32.h
#//
#// 454.13   02/12/23  HLS     - Added wc prefix to functions
#//
#// 454.16   10/25/23  HLS-DS  - Replaced const DWORD with #define macros
#//                              to resolve C compilation errors (C2099)
#//***********************************************************************




##BOOL  APIENTRY wcDoorInitialize();
wcDoorInitialize = wcdoor32_dll.wcDoorInitialize
wcDoorInitialize.restype = ctypes.wintypes.BOOL

##BOOL  APIENTRY wcDoorShutdown();
wcDoorShutdown = wcdoor32_dll.wcDoorShutdown
wcDoorShutdown.restype = ctypes.wintypes.BOOL

##BOOL  APIENTRY wcDoorWrite(const void *data, DWORD size);
wcDoorWrite = wcdoor32_dll.wcDoorWrite
wcDoorWrite.argtypes = [ctypes.c_void_p, ctypes.wintypes.DWORD]
wcDoorWrite.restype = ctypes.wintypes.BOOL

##DWORD APIENTRY wcDoorRead(void *data, DWORD size);
wcDoorRead = wcdoor32_dll.wcDoorRead
wcDoorRead.argtypes = [ctypes.POINTER(ctypes.c_void_p), ctypes.wintypes.DWORD]
wcDoorRead.restype = ctypes.wintypes.DWORD

##DWORD APIENTRY wcDoorReadPeek(void *data, DWORD size);
wcDoorReadPeek = wcdoor32_dll.wcDoorReadPeek
wcDoorReadPeek.argtypes = [ctypes.POINTER(ctypes.c_void_p), ctypes.wintypes.DWORD]
wcDoorReadPeek.restype = ctypes.wintypes.DWORD

##DWORD APIENTRY wcDoorCharReady();
wcDoorCharReady = wcdoor32_dll.wcDoorCharReady
wcDoorCharReady.restype = ctypes.wintypes.DWORD

##HANDLE APIENTRY wcDoorGetAvailableEventHandle();
wcDoorGetAvailableEventHandle = wcdoor32_dll.wcDoorGetAvailableEventHandle
wcDoorGetAvailableEventHandle.restype = ctypes.wintypes.HANDLE

##HANDLE APIENTRY wcDoorGetOfflineEventHandle();
wcDoorGetOfflineEventHandle = wcdoor32_dll.wcDoorGetOfflineEventHandle
wcDoorGetOfflineEventHandle.restype = ctypes.wintypes.HANDLE

##BOOL  APIENTRY wcDoorHangUp();
wcDoorHangUp = wcdoor32_dll.wcDoorHangUp
wcDoorHangUp.restype = ctypes.wintypes.BOOL

##DWORD APIENTRY wcDoorEvent(const DWORD timeout);
wcDoorEvent = wcdoor32_dll.wcDoorEvent
wcDoorEvent.argtypes = [ctypes.wintypes.DWORD]
wcDoorEvent.restype = ctypes.wintypes.DWORD


#} // extern "C"

